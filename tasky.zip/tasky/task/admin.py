from django.contrib import admin
from task.models import Task

# Register your models here.
admin.site.register(Task)
