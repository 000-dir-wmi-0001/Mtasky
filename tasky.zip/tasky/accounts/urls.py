from django.urls import path
from .views import delete_profile, register, login_view, profile
from django.contrib.auth.views import LogoutView  # Import the LogoutView


urlpatterns = [
    path('register/', register, name='register'),
    path('login/', login_view, name='login'),
    path('logout/', LogoutView.as_view(), name='logout'),  # Logout view URL
    path('profile/', profile, name='profile'),
    path('delete_profile/', delete_profile, name='delete_profile'),
]
